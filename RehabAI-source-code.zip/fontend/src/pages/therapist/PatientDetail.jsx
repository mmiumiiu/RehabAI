import { useState, useEffect, useRef } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import TherapistProgress from '../../components/TherapistProgress.jsx'
import LoudTargetSettings from '../../components/LoudTargetSettings.jsx'
import LoudPhraseSettings from '../../components/LoudPhraseSettings.jsx'
import { Card, Button, Badge, SectionTitle } from '../../components/ui.jsx'
import { ArrowLeft, Chat, Mic } from '../../components/icons.jsx'
import { PATIENTS, HISTORY, PARKINSON_STAGES } from '../../lib/mockData.js'
import { sessionService } from '../../lib/sessionService.js'

export default function PatientDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const patient = PATIENTS.find((p) => p.id === id) || PATIENTS[0]
  const [note, setNote] = useState('ผู้ป่วยทำท่า Sit-to-Stand ได้ดีขึ้น ควรเน้นท่าทรงตัวเพิ่มในสัปดาห์หน้า')
  const [saved, setSaved] = useState(false)
  const [liveSession, setLiveSession] = useState(null)
  const dismissTimer = useRef(null)

  useEffect(() => {
    sessionService.subscribe(patient.id, (result) => {
      setLiveSession(result)
      // auto-dismiss 5 minutes after the last update
      if (dismissTimer.current) clearTimeout(dismissTimer.current)
      dismissTimer.current = setTimeout(() => setLiveSession(null), 5 * 60 * 1000)
    })
    return () => {
      sessionService.unsubscribe()
      if (dismissTimer.current) clearTimeout(dismissTimer.current)
    }
  }, [patient.id])

  return (
    <div>
      <header className="flex justify-between items-center px-4 md:px-8 py-4 md:py-5 border-b border-line bg-surface">
        <Link to="/therapist/patients" className="inline-flex items-center gap-1.5 text-[13px] text-ink-secondary hover:text-teal-700">
          <ArrowLeft size={16} /> รายชื่อผู้ป่วย
        </Link>
        <Button variant="outline" className="w-auto py-2" onClick={() => navigate('/therapist/messages')}>
          <Chat size={16} /> แชทกับผู้ป่วย
        </Button>
      </header>

      <div className="px-4 md:px-8 py-5 md:py-7 max-w-[900px] mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <h1 className="font-heading text-[22px] font-semibold text-ink-primary">{patient.name}</h1>
          <Badge tone="big">{PARKINSON_STAGES.find((s) => s.value === patient.stage)?.short}</Badge>
        </div>

        {/* Live session card */}
        {liveSession && (
          <div className="rounded-card p-4 mb-6 flex items-center gap-4" style={{ background: liveSession.complete ? '#E4F6E9' : '#EAF3F0' }}>
            <div
              className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 text-white"
              style={{ background: liveSession.complete ? '#147A3D' : '#147A3D' }}
            >
              {liveSession.complete ? '✓' : <Mic size={18} />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[13.5px] font-semibold" style={{ color: liveSession.complete ? '#147A3D' : '#0A4023' }}>
                  {liveSession.complete ? 'เสร็จสิ้น LSVT LOUD แล้ว' : 'กำลังฝึก LSVT LOUD อยู่ขณะนี้'}
                </span>
                {!liveSession.complete && (
                  <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse flex-shrink-0" />
                )}
              </div>
              <div className="text-[12px] mt-0.5" style={{ color: liveSession.complete ? '#147A3D' : '#147A3D' }}>
                {liveSession.reps} / {liveSession.goal} ครั้ง · {liveSession.duration}
              </div>
            </div>
            <div className="text-right flex-shrink-0">
              <div
                className="font-heading text-[24px] font-semibold"
                style={{ color: liveSession.complete ? '#147A3D' : '#0A4023' }}
              >
                {Math.round((liveSession.reps / liveSession.goal) * 100)}%
              </div>
              <div className="text-[11px] text-ink-muted">สำเร็จ</div>
            </div>
          </div>
        )}

        <TherapistProgress />

        <SectionTitle>ตั้งค่า LSVT LOUD สำหรับผู้ป่วยคนนี้</SectionTitle>
        <LoudTargetSettings />
        <LoudPhraseSettings />

        <SectionTitle>ประวัติล่าสุด</SectionTitle>
        <div className="overflow-x-auto mb-7">
          <table className="w-full border-collapse card overflow-hidden min-w-[420px]">
            <thead>
              <tr className="bg-[#F1EFF9]">
                {['วันที่', 'ประเภทการฝึก', 'ระยะเวลา'].map((h) => (
                  <th key={h} className="text-left text-[11.5px] uppercase tracking-wide text-ink-muted px-5 py-3 font-semibold">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {HISTORY.map((r, i) => (
                <tr key={i} className="border-t border-line">
                  <td className="px-5 py-3 text-[13.5px]">{r.date}</td>
                  <td className="px-5 py-3"><Badge tone={r.type}>{r.type === 'big' ? 'LSVT BIG' : 'LSVT LOUD'}</Badge></td>
                  <td className="px-5 py-3 text-[13.5px]">{r.duration}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <SectionTitle>บันทึกของฉัน (เห็นเฉพาะนักกายภาพบำบัด ไม่กระทบโปรแกรมฝึกของผู้ป่วย)</SectionTitle>
        <Card className="p-5">
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={4}
            className="w-full border border-line rounded-btn p-3 text-[13.5px] outline-none focus:border-teal-700 resize-y"
          />
          <Button variant="primary" className="w-auto mt-3" onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000) }}>
            {saved ? 'บันทึกแล้ว ✓' : 'บันทึก'}
          </Button>
        </Card>
      </div>
    </div>
  )
}
