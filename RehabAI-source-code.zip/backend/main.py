from fastapi import FastAPI, Request, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel
from typing import List
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
import json, pathlib, os, hmac, hashlib, base64, httpx, secrets, time, io
from gtts import gTTS
from dotenv import load_dotenv
from lsvt_loud import router as lsvt_router
load_dotenv()

BASE = pathlib.Path(__file__).parent

# ── model definition: copied verbatim from Cell 8 ───────────────────────────
class QualityNet(nn.Module):
    def __init__(self, n_feat, n_ex, d=64, n_emb=8):
        super().__init__()
        self.emb = nn.Embedding(n_ex, n_emb)
        self.stem = nn.Sequential(
            nn.Conv1d(n_feat, d, 5, padding=2), nn.BatchNorm1d(d), nn.ReLU(), nn.Dropout(0.2),
            nn.Conv1d(d, d, 3, padding=2, dilation=2), nn.BatchNorm1d(d), nn.ReLU(), nn.Dropout(0.2),
            nn.Conv1d(d, d, 3, padding=4, dilation=4), nn.BatchNorm1d(d), nn.ReLU(),
        )
        self.head = nn.Sequential(
            nn.Linear(2*d + n_emb, 64), nn.ReLU(), nn.Dropout(0.3), nn.Linear(64, 2))
    def forward(self, x, e):
        x = self.stem(x.permute(0, 2, 1))
        x = torch.cat([x.mean(-1), x.max(-1).values], -1)
        return self.head(torch.cat([x, self.emb(e)], -1))

# ── feature engineering: copied verbatim from Cell 5 ────────────────────────
class L:
    LEFT_SHOULDER, RIGHT_SHOULDER = 11, 12
    LEFT_ELBOW, RIGHT_ELBOW = 13, 14
    LEFT_WRIST, RIGHT_WRIST = 15, 16
    LEFT_HIP, RIGHT_HIP = 23, 24
    LEFT_KNEE, RIGHT_KNEE = 25, 26
    LEFT_ANKLE, RIGHT_ANKLE = 27, 28

def normalize_pose(seq):
    xyz = seq[..., :3].copy()
    mid_hip = (xyz[:, L.LEFT_HIP] + xyz[:, L.RIGHT_HIP]) / 2
    mid_sho = (xyz[:, L.LEFT_SHOULDER] + xyz[:, L.RIGHT_SHOULDER]) / 2
    torso = np.clip(np.linalg.norm(mid_sho - mid_hip, axis=-1, keepdims=True), 1e-3, None)
    return (xyz - mid_hip[:, None, :]) / torso[:, None, :]

def angle(a, b, c):
    ba, bc = a - b, c - b
    cos = np.sum(ba*bc, -1) / (np.linalg.norm(ba, axis=-1)*np.linalg.norm(bc, axis=-1) + 1e-8)
    return np.degrees(np.arccos(np.clip(cos, -1, 1)))

ANGLE_DEFS = {
    "elbow_L": (L.LEFT_SHOULDER, L.LEFT_ELBOW, L.LEFT_WRIST),
    "elbow_R": (L.RIGHT_SHOULDER, L.RIGHT_ELBOW, L.RIGHT_WRIST),
    "shoulder_L": (L.LEFT_ELBOW, L.LEFT_SHOULDER, L.LEFT_HIP),
    "shoulder_R": (L.RIGHT_ELBOW, L.RIGHT_SHOULDER, L.RIGHT_HIP),
    "hip_L": (L.LEFT_SHOULDER, L.LEFT_HIP, L.LEFT_KNEE),
    "hip_R": (L.RIGHT_SHOULDER, L.RIGHT_HIP, L.RIGHT_KNEE),
    "knee_L": (L.LEFT_HIP, L.LEFT_KNEE, L.LEFT_ANKLE),
    "knee_R": (L.RIGHT_HIP, L.RIGHT_KNEE, L.RIGHT_ANKLE),
}
ANGLE_NAMES = list(ANGLE_DEFS)

def joint_angles(xyz):
    return np.stack([angle(xyz[:, a], xyz[:, b], xyz[:, c])
                     for a, b, c in ANGLE_DEFS.values()], -1).astype(np.float32)

SEQ_LEN = 48
def resample(a, T=SEQ_LEN):
    n = len(a)
    if n < 2: return np.repeat(a[:1], T, 0)
    idx = np.linspace(0, n-1, T)
    lo, hi = np.floor(idx).astype(int), np.ceil(idx).astype(int)
    w = (idx - lo)[:, None]
    return (a[lo]*(1-w) + a[hi]*w).astype(np.float32)

def build_rep(seq_raw, fps=30.0):
    ok = ~np.isnan(seq_raw[..., :3]).any((1, 2))
    if ok.sum() < 5: return None
    seq_raw = seq_raw[ok]
    xyz = normalize_pose(seq_raw)
    ang = joint_angles(xyz)
    duration = len(seq_raw) / fps
    vel = np.diff(ang, axis=0, prepend=ang[:1]) * fps
    seq_feat = np.concatenate([xyz.reshape(len(xyz), -1), ang, vel], -1)
    summ = []
    for i in range(len(ANGLE_NAMES)):
        a = ang[:, i]; summ += [a.min(), a.max(), a.max()-a.min(), a.mean(), a.std()]
    for i in range(len(ANGLE_NAMES)):
        v = np.abs(vel[:, i]); summ += [v.mean(), v.max()]
    summ += [duration, float(np.nanmean(seq_raw[..., 3]))]
    return {"seq": resample(seq_feat), "summ": np.asarray(summ, np.float32), "duration": duration}

# ── load model ───────────────────────────────────────────────────────────────
meta = json.loads((BASE / "meta.json").read_text())
stats = np.load(BASE / "norm_stats.npz")
MU, SD, TEMP = stats["mean"], stats["std"], meta["temperature"]
EX_MAP = {v: int(k) for k, v in meta["exercise_map"].items() if v}
net = QualityNet(meta["n_features"], meta["n_exercises"])
net.load_state_dict(torch.load(BASE / "quality_net.pt", map_location="cpu"))
net.eval()

# ── app ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="RehabAI Scoring API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# LSVT LOUD voice scoring (dB band + word accuracy) — see lsvt_loud.py
app.include_router(lsvt_router)

class ScoreRequest(BaseModel):
    landmarks: List[List[List[float]]]  # [n_frames][33][4: x,y,z,visibility]
    exercise: str
    fps: float = 20.0

LINE_TOKEN = os.getenv("LINE_CHANNEL_ACCESS_TOKEN", "")
LINE_SECRET = os.getenv("LINE_CHANNEL_SECRET", "")
LINE_PUSH_URL = "https://api.line.me/v2/bot/message/push"

# In-memory link-code store: code -> {expires, userId|None}
# Codes expire after 10 minutes. Users send the code as a Line message to link accounts.
_link_codes: dict[str, dict] = {}

def _verify_line_signature(body: bytes, signature: str) -> bool:
    if not LINE_SECRET:
        return True  # skip verification in dev if secret not set
    mac = hmac.new(LINE_SECRET.encode(), body, hashlib.sha256).digest()
    return hmac.compare_digest(base64.b64encode(mac).decode(), signature)

async def _push_line(user_id: str, text: str):
    if not LINE_TOKEN:
        print(f"[Line stub→{user_id}] {text}")
        return
    async with httpx.AsyncClient() as client:
        await client.post(
            LINE_PUSH_URL,
            headers={"Authorization": f"Bearer {LINE_TOKEN}"},
            json={"to": user_id, "messages": [{"type": "text", "text": text}]},
        )

@app.post("/line/link-code")
def generate_link_code():
    """Generate a short code the patient sends to the Line OA to link their account."""
    code = secrets.token_hex(3).upper()  # 6 hex chars e.g. "A3F9B2"
    now = time.time()
    _link_codes[code] = {"expires": now + 600, "userId": None}
    # Prune expired codes
    for k in [k for k, v in _link_codes.items() if v["expires"] < now]:
        _link_codes.pop(k, None)
    return {"code": code}

@app.get("/line/link-code/{code}")
def check_link_code(code: str):
    """Poll this until userId is non-null — means the patient messaged the OA."""
    entry = _link_codes.get(code.upper())
    if not entry or entry["expires"] < time.time():
        return {"userId": None, "expired": True}
    return {"userId": entry["userId"], "expired": False}

@app.post("/line/webhook")
async def line_webhook(request: Request):
    body = await request.body()
    sig = request.headers.get("X-Line-Signature", "")
    if not _verify_line_signature(body, sig):
        raise HTTPException(status_code=400, detail="invalid signature")

    data = json.loads(body)
    for event in data.get("events", []):
        if event.get("type") != "message":
            continue
        if event.get("source", {}).get("type") != "user":
            continue
        user_id = event["source"]["userId"]
        msg_text = event.get("message", {}).get("text", "").strip().upper()

        # Check if message is a valid link code
        entry = _link_codes.get(msg_text)
        if entry and entry["expires"] > time.time() and entry["userId"] is None:
            entry["userId"] = user_id
            await _push_line(user_id, "✅ เชื่อมต่อ RehabAI สำเร็จแล้ว!\nคุณจะได้รับการแจ้งเตือนการฝึกทาง Line นี้ 💪")
        else:
            # Unknown message — send help
            await _push_line(user_id, "สวัสดี! ส่งรหัสเชื่อมต่อจากแอป RehabAI มาที่นี่เพื่อเปิดใช้การแจ้งเตือน")

    return {"status": "ok"}

@app.post("/line/send")
async def line_send(payload: dict):
    """Push a message to a patient's Line account."""
    user_id = payload.get("userId")
    text = payload.get("text")
    if not user_id or not text:
        raise HTTPException(status_code=422, detail="userId and text required")
    await _push_line(user_id, text)
    return {"ok": True}

@app.get("/health")
def health():
    return {"status": "ok", "exercises": list(EX_MAP.keys())}

# ── LSVT LOUD daily-life phrases (therapist-curated, shared to the patient) ─────
# Kept in memory; the therapist POSTs the list, the patient GETs/polls it so
# edits show up on the patient side without a reload — across devices too.
loud_phrases_store: list[str] = [
    "สวัสดี", "ขอโทษ", "ขอบคุณ", "ไม่เป็นไร", "สบายดีไหม",
    "ไปห้องน้ำ", "หิวข้าว", "ช่วยพาไปที่เตียงนอนหน่อย",
    "วันนี้ต้องไปที่ไหนบ้าง", "ขอดูเมนูหน่อย",
]


@app.get("/loud-phrases")
def get_loud_phrases():
    return {"phrases": loud_phrases_store}


@app.post("/loud-phrases")
def set_loud_phrases(payload: dict):
    global loud_phrases_store
    items = payload.get("phrases")
    if isinstance(items, list):
        loud_phrases_store = [str(x).strip() for x in items if str(x).strip()][:100]
    return {"phrases": loud_phrases_store}

@app.get("/tts")
def tts(text: str = Query(..., min_length=1, max_length=500)):
    """Thai text-to-speech via gTTS. Returns an mp3 so the voice is identical on
    every device, independent of the OS's installed voices."""
    try:
        buf = io.BytesIO()
        gTTS(text=text, lang="th").write_to_fp(buf)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"tts failed: {e}")
    return Response(
        content=buf.getvalue(),
        media_type="audio/mpeg",
        headers={"Cache-Control": "public, max-age=86400"},
    )

@app.post("/score")
def score(req: ScoreRequest):
    if req.exercise not in EX_MAP:
        return {"conf": 0.0, "verdict": "unsupported", "duration": 0.0, "rom": {}}

    seq_raw = np.asarray(req.landmarks, dtype=np.float32)
    rep = build_rep(seq_raw, fps=req.fps)
    if rep is None:
        return {"conf": 0.0, "verdict": "too_short", "duration": 0.0, "rom": {}}

    x = torch.from_numpy(((rep["seq"] - MU) / SD).astype(np.float32))[None]
    e = torch.tensor([EX_MAP[req.exercise]])
    with torch.no_grad():
        p = F.softmax(net(x, e) / TEMP, 1).numpy()[0]

    conf = float(p[1])
    return {
        "conf": conf,
        "verdict": "correct" if conf >= 0.5 else "needs_work",
        "duration": rep["duration"],
        "rom": {n: float(rep["summ"][i * 5 + 2]) for i, n in enumerate(ANGLE_NAMES)},
    }


# ── Real-time chat relay (patient ⇄ therapist) ─────────────────────────────────
# Each thread (= patient id) is a room. Clients send {type:'join', threadId} to
# subscribe (and receive recent history), then {type:'message', ...} to post;
# every message is broadcast to everyone in the room, including the sender.
chat_rooms: dict[str, set[WebSocket]] = {}
chat_history: dict[str, list[dict]] = {}


@app.websocket("/ws/chat")
async def ws_chat(ws: WebSocket):
    await ws.accept()
    thread = None
    try:
        while True:
            data = await ws.receive_json()
            kind = data.get("type")

            if kind == "join":
                thread = data.get("threadId")
                chat_rooms.setdefault(thread, set()).add(ws)
                await ws.send_json({"type": "history", "messages": chat_history.get(thread, [])})

            elif kind == "message":
                thread = data.get("threadId", thread)
                if not thread:
                    continue
                message = {
                    "id": data.get("id"),
                    "from": data.get("from"),
                    "text": data.get("text"),
                    "at": data.get("at"),
                    "threadId": thread,
                }
                history = chat_history.setdefault(thread, [])
                history.append(message)
                del history[:-200]  # keep the last 200
                dead = []
                for peer in list(chat_rooms.get(thread, set())):
                    try:
                        await peer.send_json({"type": "message", "message": message})
                    except Exception:
                        dead.append(peer)
                for d in dead:
                    chat_rooms.get(thread, set()).discard(d)
    except WebSocketDisconnect:
        pass
    finally:
        for room in chat_rooms.values():
            room.discard(ws)
